# LineChartExample
The sample application from my LineChartDemo post on Medium

Feel free to use my code and use it to learn — break it, fix it or even turn it into a line graph! 

Any comments or issues, you can comment on my Medium post or make an issue on the github page. I will try to get back to you!

Link to article: 
https://medium.com/@OsianSmith/creating-a-line-chart-in-swift-3-and-ios-10-2f647c95392e
